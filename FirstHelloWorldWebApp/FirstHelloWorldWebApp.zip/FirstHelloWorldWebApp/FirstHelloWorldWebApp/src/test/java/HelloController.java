import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Controller
public class HelloController {

    @GetMapping("/errors")
    public String hello() {
        // Simulate an error (for testing purposes)
        throw new RuntimeException("This is a custom error message.");
    }

    @ExceptionHandler(Exception.class)
    public String handleException(Exception ex, Model model) {
        model.addAttribute("errorMessage", ex.getMessage());
        return "error"; // This will render the "error.html" template with the custom error message.
    }
}
