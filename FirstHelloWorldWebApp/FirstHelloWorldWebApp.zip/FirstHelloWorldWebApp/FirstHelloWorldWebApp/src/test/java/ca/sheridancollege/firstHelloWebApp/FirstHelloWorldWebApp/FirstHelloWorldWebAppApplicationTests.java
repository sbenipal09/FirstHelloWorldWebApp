package ca.sheridancollege.firstHelloWebApp.FirstHelloWorldWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstHelloWorldWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
