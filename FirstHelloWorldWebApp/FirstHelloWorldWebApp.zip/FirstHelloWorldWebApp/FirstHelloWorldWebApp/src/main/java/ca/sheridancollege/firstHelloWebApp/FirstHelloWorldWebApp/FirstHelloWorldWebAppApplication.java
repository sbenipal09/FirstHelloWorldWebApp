package ca.sheridancollege.firstHelloWebApp.FirstHelloWorldWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstHelloWorldWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstHelloWorldWebAppApplication.class, args);
	}

}
